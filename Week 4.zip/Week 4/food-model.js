export class FoodModel {
    constructor (id, name, calories) {
        this.id = id;
        this.name = name;
        this.calories = calories;
    }
}
