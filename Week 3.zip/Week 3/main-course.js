import { Product } from "./product.js";
export class mainCourse extends Product
{
    constructor(name, price)
    {
        super(name, price);
    }
}