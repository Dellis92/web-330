import { Product } from "./product.js";
export class Appetizer extends Product
{
    constructor(name, price)
    {
        super(name, price);
    }
}